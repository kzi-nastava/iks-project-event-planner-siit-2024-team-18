import {
  MatDivider,
  MatDividerModule
} from "./chunk-X2NAMIBB.js";
import "./chunk-5YE556SD.js";
import "./chunk-TTAMARSV.js";
import "./chunk-M4ZQSH5N.js";
import "./chunk-4N4GOYJH.js";
import "./chunk-5OPE3T2R.js";
import "./chunk-FHTVLBLO.js";
import "./chunk-3OV72XIM.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
