import {
  Calendar,
  JsonRequestError,
  createPlugin,
  formatDate,
  formatRange,
  globalLocales,
  globalPlugins,
  sliceEvents,
  version
} from "./chunk-JJ75LRMA.js";
import "./chunk-3OV72XIM.js";
export {
  Calendar,
  JsonRequestError,
  createPlugin,
  formatDate,
  formatRange,
  globalLocales,
  globalPlugins,
  sliceEvents,
  version
};
//# sourceMappingURL=@fullcalendar_core.js.map
