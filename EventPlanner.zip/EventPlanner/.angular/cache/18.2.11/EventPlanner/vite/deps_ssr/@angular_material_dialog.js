import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  MAT_DIALOG_DATA,
  MAT_DIALOG_DEFAULT_OPTIONS,
  MAT_DIALOG_SCROLL_STRATEGY,
  MAT_DIALOG_SCROLL_STRATEGY_PROVIDER,
  MAT_DIALOG_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MatDialog,
  MatDialogActions,
  MatDialogClose,
  MatDialogConfig,
  MatDialogContainer,
  MatDialogContent,
  MatDialogModule,
  MatDialogRef,
  MatDialogState,
  MatDialogTitle,
  _closeDialogVia,
  _defaultParams,
  matDialogAnimations
} from "./chunk-3AGKIAHQ.js";
import "./chunk-VW4TDS73.js";
import "./chunk-QMXQBEA7.js";
import "./chunk-FY2PTGSB.js";
import "./chunk-5F66ZG5C.js";
import "./chunk-L2YUVUV6.js";
import "./chunk-DV5FXBKA.js";
import "./chunk-WG3KBWZJ.js";
import "./chunk-5IW5ZEPE.js";
import "./chunk-UOPINYA3.js";
import "./chunk-RPWZ4CMX.js";
import "./chunk-NQ4HTGF6.js";
export {
  MAT_DIALOG_DATA,
  MAT_DIALOG_DEFAULT_OPTIONS,
  MAT_DIALOG_SCROLL_STRATEGY,
  MAT_DIALOG_SCROLL_STRATEGY_PROVIDER,
  MAT_DIALOG_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MatDialog,
  MatDialogActions,
  MatDialogClose,
  MatDialogConfig,
  MatDialogContainer,
  MatDialogContent,
  MatDialogModule,
  MatDialogRef,
  MatDialogState,
  MatDialogTitle,
  _closeDialogVia,
  _defaultParams,
  matDialogAnimations
};
//# sourceMappingURL=@angular_material_dialog.js.map
