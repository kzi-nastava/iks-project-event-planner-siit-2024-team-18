import { createRequire } from 'module';const require = createRequire(import.meta.url);
//# sourceMappingURL=chunk-VUYRRVWM.js.map
