import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  MatDivider,
  MatDividerModule
} from "./chunk-NF6A3WWJ.js";
import "./chunk-L2YUVUV6.js";
import "./chunk-DV5FXBKA.js";
import "./chunk-WG3KBWZJ.js";
import "./chunk-5IW5ZEPE.js";
import "./chunk-UOPINYA3.js";
import "./chunk-RPWZ4CMX.js";
import "./chunk-NQ4HTGF6.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
