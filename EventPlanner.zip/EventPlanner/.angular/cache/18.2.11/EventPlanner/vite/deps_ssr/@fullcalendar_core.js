import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  Calendar,
  JsonRequestError,
  createPlugin,
  formatDate,
  formatRange,
  globalLocales,
  globalPlugins,
  sliceEvents,
  version
} from "./chunk-IQSMAVKR.js";
import "./chunk-NQ4HTGF6.js";
export {
  Calendar,
  JsonRequestError,
  createPlugin,
  formatDate,
  formatRange,
  globalLocales,
  globalPlugins,
  sliceEvents,
  version
};
//# sourceMappingURL=@fullcalendar_core.js.map
