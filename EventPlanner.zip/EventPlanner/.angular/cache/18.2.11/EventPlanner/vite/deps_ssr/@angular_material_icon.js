import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  ICON_REGISTRY_PROVIDER,
  ICON_REGISTRY_PROVIDER_FACTORY,
  MAT_ICON_DEFAULT_OPTIONS,
  MAT_ICON_LOCATION,
  MAT_ICON_LOCATION_FACTORY,
  MatIcon,
  MatIconModule,
  MatIconRegistry,
  getMatIconFailedToSanitizeLiteralError,
  getMatIconFailedToSanitizeUrlError,
  getMatIconNameNotFoundError,
  getMatIconNoHttpProviderError
} from "./chunk-PD5WXBCA.js";
import "./chunk-WHBG7UEB.js";
import "./chunk-BQHKYAAK.js";
import "./chunk-L2YUVUV6.js";
import "./chunk-DV5FXBKA.js";
import "./chunk-WG3KBWZJ.js";
import "./chunk-5IW5ZEPE.js";
import "./chunk-UOPINYA3.js";
import "./chunk-RPWZ4CMX.js";
import "./chunk-NQ4HTGF6.js";
export {
  ICON_REGISTRY_PROVIDER,
  ICON_REGISTRY_PROVIDER_FACTORY,
  MAT_ICON_DEFAULT_OPTIONS,
  MAT_ICON_LOCATION,
  MAT_ICON_LOCATION_FACTORY,
  MatIcon,
  MatIconModule,
  MatIconRegistry,
  getMatIconFailedToSanitizeLiteralError,
  getMatIconFailedToSanitizeUrlError,
  getMatIconNameNotFoundError,
  getMatIconNoHttpProviderError
};
//# sourceMappingURL=@angular_material_icon.js.map
