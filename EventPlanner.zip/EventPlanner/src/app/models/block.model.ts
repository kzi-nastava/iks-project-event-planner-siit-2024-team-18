export interface Block {
    id: number;
    blockedDate?: Date;
    blockerId: number;
    blockedId: number;
  }