export interface BudgetItem {
    id: number;
    maxAmount: number;
    categoryName: string;
}
