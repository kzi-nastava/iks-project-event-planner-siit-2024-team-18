export interface EventCard {
    id: number;
    name: string;
    description: string;
    locationName: string;
    cardImage: string;
  }
  