export interface UpdatedInvite {
    inviteId: number;
    invitationStatus: string;
    message: string;
    updatedAt: string;
    loggedIn: boolean;
  }