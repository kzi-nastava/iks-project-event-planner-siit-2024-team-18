export interface NotificationCard {
    id: number;
    title: string;
    content: string;
    date: string;
    seen: boolean;
    itemId: number;
    notificationType: string;
  }