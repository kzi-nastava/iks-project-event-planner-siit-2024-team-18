export interface CommentRequest {
    id: number;
    content: string;
    date: Date;
    status: string;
  }