import { Reservation } from "../models/reservation.model";

const mockReservation1: Reservation = { reservationId: 1, serviceId: 1, eventId: 1, date: '2025-02-01', timeFrom: '10:00', timeTo: '12:00', status: 'Confirmed' };

export { mockReservation1 };