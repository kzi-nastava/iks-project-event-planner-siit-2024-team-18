import { EventCard } from "../models/event-card.model";

const mockEvent1: EventCard = { id: 1, name: 'Event 1', description: 'Event Description', locationName: 'Location', cardImage: 'image.jpg' };

export { mockEvent1 };