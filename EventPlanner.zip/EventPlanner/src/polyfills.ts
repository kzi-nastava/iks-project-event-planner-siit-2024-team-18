import 'zone.js';
(window as any).global = window;
