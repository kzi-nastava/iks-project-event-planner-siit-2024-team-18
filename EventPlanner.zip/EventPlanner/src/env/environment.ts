export const environment = {
    apiHost: 'http://localhost:8080',
};